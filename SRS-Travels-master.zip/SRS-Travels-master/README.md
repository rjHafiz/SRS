# SRS-Travels
This is the project in which I collaborated with my friends Sahab Al Chowdhury and Rafin Jawad Hafiz for Visual Programming Lab in 4th semester of coursework. Here a user can book hotels, flights and car rentals at a few destinations and admin can control the activities.
It is a very simple project with minimalistic UI but we plan to work on it in the future to make it worth using.

You can just download the project and run it on IntelliJ IDEA or any other suitable IDE which can run Java, JavaFX and MYSQL database.
The tables have to be created in MYSQL.
